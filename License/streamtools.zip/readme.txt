Inv Softworks LLC   www.flexhex.com
Copyright (c) 2005. All rights reserved.

These command-line tools provide a full set of stream handling commands, which
can be called from a batch file or used directly in a command line. In order
to install the tools just unpack them to any directory. To avoid specifying
the full path every time, unpack the tools to a directory that is listed in
the PATH environment variable; the Windows directory is an example of an
appropriate place.

This command line utility supplements the article "NTFS Alternate
Streams: What, When, and How To", which can be found at
http://www.flexhex.com/docs/articles/alternate-streams.phtml

You can use these tools without charge for any commercial or non-commercial
purpose. You can distribute these tools freely provided that you are
distributing the original zip archive including this README file.

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
"AS IS" AND INV SOFTWORKS LLC DISCLAIMS ALL OTHER WARRANTIES AND CONDITIONS,
EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, CONFORMANCE WITH
DESCRIPTION, TITLE AND NON-INFRINGEMENT OF THIRD PARTY RIGHTS.


COPY STREAM

Usage:

  cs from_stream to_stream

This command copies separate streams, for example

  cs C:\SomeFile.dat:str stream.dat:alt

If the stream is not specified, the command assumes the unnamed stream.
For example, the command

  cs c:\report.txt reports.txt:r20

will copy the file's primary stream. If the file report.txt has any alternate
streams, they will be ignored (use the standard copy command to copy the file
as a whole).


DELETE STREAM

Usage:

  ds stream

Delete the specified stream, for example

  ds stream.dat:alt

If no stream name is specified, the command deletes the whole file
(deleting the unnamed stream causes all the streams to be deleted).

The command don't ask for confirmation, so be careful.


RENAME STREAM

There is no known method of renaming a stream, so we have to use the
copy/delete sequence. While this method will do the trick, renaming
a large stream may take considerable time.

Usage:

  rs file oldname newname

Rename the stream oldname of the file file to newname. For example, the command

  rs stream.dat alt text

renames stream.dat:alt to stream.dat:text.


LIST STREAMS

This command lists all streams of the specified file and their size.

Usage:

  ls file

The LS command returns the standard success code 0 only if at least one
alternate stream was found. See the topic "Calling From a Batch File"
below for a usage example.


CALLING FROM A BATCH FILE

Like most standard command line commands, the stream commands return
the standard exit codes that can be analyzed with the if errorlevel
batch command. There are two possible exit codes: 0 means success,
and 1 means error. The technique is illustrated by the following example
batch file:

	@echo off
	echo Copying stream...

	cs c:\report.txt reports.txt:20
	if errorlevel 1 goto cmderr
	echo Successfully copied!
	goto exitbatch

	:cmderr
	echo Some error occured.

	:exitbatch
	rem Exiting the batch file....


FIND STREAMS

The LS command returns the standard success code 0 when at least one
alternate stream present. The standard error code 1 is returned if
the file contains an unnamed stream only or if I/O error occured.
The following example shows how to check for presence of alternate
streams:

	@echo off
	rem This batch file finds and list all files with ADS in the current directory

	echo Files containing alternate streams:

	for %%f in (*.*) do call :checkf %%f
	goto exitbatch

	:checkf
	rem We don't want to list streams so throw out the output
	ls %1 >nul
	if not errorlevel 1 echo %1

	:exitbatch

This batch file FS.bat is included as a part of the stream tools package.
